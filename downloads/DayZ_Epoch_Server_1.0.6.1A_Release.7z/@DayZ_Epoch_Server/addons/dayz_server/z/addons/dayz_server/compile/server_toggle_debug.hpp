/*
Created exclusively for ArmA2:OA - DayZMod.
Please request permission to use/alter/distribute from project leader (R4Z0R49)
*/

//// TOGGLE DEBUGS ////

// comment this out if you don't want any LOGIN related debug
#define LOGIN_DEBUG

// comment this out if you don't want any VEHICLE/TENT/OBJECT related debug
#define OBJECT_DEBUG

// comment this out if you don't want any PLAYER (WORLDSPACE/INVENTORY/ETC) related debug
#define PLAYER_DEBUG

// comment this out if you don't want any misc SERVER (ZOMBIE, LOOT, CLEANUP) related debug
//#define SERVER_DEBUG

