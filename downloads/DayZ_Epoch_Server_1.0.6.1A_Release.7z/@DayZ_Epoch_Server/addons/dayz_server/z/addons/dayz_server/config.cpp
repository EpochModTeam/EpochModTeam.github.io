////////////////////////////////////////////////////////////////////
//DeRap: Produced from mikero's Dos Tools Dll version 6.08
//'now' is Sun Mar 12 16:41:24 2017 : 'file' last modified on Sun Mar 12 16:25:15 2017
//http://dev-heaven.net/projects/list_files/mikero-pbodll
////////////////////////////////////////////////////////////////////

#define _ARMA_

//Class dayz_server : config.bin{
class CfgPatches
{
	class dayz_server
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.1;
		requiredAddons[] = {"dayz_code"};
	};
};
//};
